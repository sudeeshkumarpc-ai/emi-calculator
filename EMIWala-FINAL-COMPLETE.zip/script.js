
const $=id=>document.getElementById(id);
let tenureMode='years',method='reducing',chart=null;
const money=n=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:2}).format(Number.isFinite(n)?n:0);
function months(){return tenureMode==='years'?Math.max(1,+$('years').value||1)*12:Math.max(1,+$('months').value||1)}
function scheduleReducing(P,rate,n,extra=0){
 const r=(rate/100)/12; let emi=r?P*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1):P/n;
 const pay=emi+Math.max(0,extra), rows=[]; let bal=P;
 for(let m=1;m<=n && bal>.005;m++){let interest=bal*r, principal=Math.min(bal,Math.max(0,pay-interest)); if(principal<=0)break; let actual=principal+interest; bal=Math.max(0,bal-principal); rows.push({m,principal,interest,payment:actual,balance:bal})}
 return {emi,rows,interest:rows.reduce((s,x)=>s+x.interest,0)};
}
function scheduleFlat(P,rate,n){
 const interest=P*(rate/100/12)*n,total=P+interest,emi=total/n,rows=[];let bal=P;
 for(let m=1;m<=n;m++){let p=P/n,i=interest/n;bal=Math.max(0,bal-p);rows.push({m,principal:p,interest:i,payment:p+i,balance:bal})}
 return {emi,rows,interest};
}
function calculate(){
 const P=Math.max(100,+$('amount').value||100), n=months(), rate=Math.max(0,+$('rate').value||0), extra=Math.max(0,+$('extra').value||0);
 const r=method==='flat'?scheduleFlat(P,rate,n):scheduleReducing(P,rate,n,extra);
 const total=P+r.interest;
 $('emi').textContent=money(r.emi);$('interest').textContent=money(r.interest);$('total').textContent=money(total);
 $('summary').innerHTML=`<b>Loan Amount</b><span>${money(P)}</span><b>Interest Rate</b><span>${rate}% p.a.</span><b>Tenure</b><span>${tenureMode==='years'?$('years').value+' Years':$('months').value+' Months'}</span><b>Monthly EMI</b><span>${money(r.emi)}</span><b>Total Interest</b><span>${money(r.interest)}</span><b>Total Payment</b><span>${money(total)}</span>`;
 let byYear=[];for(let i=0;i<r.rows.length;i+=12){let c=r.rows.slice(i,i+12);byYear.push({y:Math.floor(i/12)+1,p:c.reduce((s,x)=>s+x.principal,0),i:c.reduce((s,x)=>s+x.interest,0),pay:c.reduce((s,x)=>s+x.payment,0),b:c.at(-1).balance})}
 $('schedule').innerHTML=byYear.map(x=>`<tr><td>Year ${x.y}</td><td>${money(x.p)}</td><td>${money(x.i)}</td><td>${money(x.pay)}</td><td>${money(x.b)}</td></tr>`).join('');
 if(chart)chart.destroy();chart=new Chart($('chart'),{type:'doughnut',data:{labels:['Principal','Interest'],datasets:[{data:[P,r.interest]}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}}}});
 window._rows=r.rows;
}
function setTenure(mode){
 tenureMode=mode;
 $('yearsBox').style.display=mode==='years'?'block':'none';$('monthsBox').style.display=mode==='months'?'block':'none';
 $('yearsTab').classList.toggle('active',mode==='years');$('monthsTab').classList.toggle('active',mode==='months');calculate();
}
function setMethod(m){method=m;$('reduceTab').classList.toggle('active',m==='reducing');$('flatTab').classList.toggle('active',m==='flat');calculate()}
document.querySelectorAll('.quickM').forEach(b=>b.onclick=()=>{$('months').value=b.dataset.v;calculate()});
document.querySelectorAll('.quickY').forEach(b=>b.onclick=()=>{$('years').value=b.dataset.v;calculate()});
['amount','rate','years','months','extra'].forEach(id=>$(id).addEventListener('input',calculate));
$('yearsTab').onclick=()=>setTenure('years');$('monthsTab').onclick=()=>setTenure('months');$('reduceTab').onclick=()=>setMethod('reducing');$('flatTab').onclick=()=>setMethod('flat');
$('amountR').oninput=e=>{$('amount').value=e.target.value;calculate()};$('amount').oninput=e=>{$('amountR').value=e.target.value;calculate()};
$('csv').onclick=()=>{let h='Month,Principal,Interest,Payment,Balance\n';let c=h+window._rows.map(x=>[x.m,x.principal.toFixed(2),x.interest.toFixed(2),x.payment.toFixed(2),x.balance.toFixed(2)].join(',')).join('\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([c],{type:'text/csv'}));a.download='emiwala-amortization.csv';a.click()};
$('reset').onclick=()=>{amount.value=5000000;amountR.value=5000000;rate.value=8.5;years.value=20;months.value=6;extra.value=0;setTenure('years');setMethod('reducing')};
calculate();
